CREATE DATABASE  IF NOT EXISTS `pinecone` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `pinecone`;
-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: pinecone
-- ------------------------------------------------------
-- Server version	5.7.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event` (
  `idEvent` int(11) NOT NULL,
  `EventName` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idEvent`),
  UNIQUE KEY `idEvent_UNIQUE` (`idEvent`),
  UNIQUE KEY `EventName_UNIQUE` (`EventName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event`
--

LOCK TABLES `event` WRITE;
/*!40000 ALTER TABLE `event` DISABLE KEYS */;
INSERT INTO `event` VALUES (15,'ActivityTaskCancelled'),(18,'ActivityTaskCompleted'),(16,'ActivityTaskFailed'),(13,'ActivityTaskScheduled'),(14,'ActivityTaskStarted'),(17,'ActivityTaskTimedOut'),(11,'ChildWorkflowExecutionCompleted'),(9,'ChildWorkflowExecutionFailed'),(8,'ChildWorkflowExecutionStarted'),(10,'ChildWorkflowExecutionTerminated'),(12,'ChildWorkflowExecutionTimedOut'),(23,'DecisionTaskCompleted'),(20,'DecisionTaskScheduled'),(21,'DecisionTaskStarted'),(22,'DecisionTaskTimedOut'),(19,'MarkerRecorded'),(7,'StartChildWorkflowExecutionInitiated'),(3,'WorkflowExecutionCancelled'),(5,'WorkflowExecutionCompleted'),(2,'WorkflowExecutionFailed'),(1,'WorkflowExecutionStarted'),(4,'WorkflowExecutionTerminated'),(6,'WorkflowExecutionTimedOut');
/*!40000 ALTER TABLE `event` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-03-18 22:04:25
