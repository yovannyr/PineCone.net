CREATE DATABASE  IF NOT EXISTS `pinecone` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `pinecone`;
-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: pinecone
-- ------------------------------------------------------
-- Server version	5.7.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping events for database 'pinecone'
--
/*!50106 SET @save_time_zone= @@TIME_ZONE */ ;
/*!50106 DROP EVENT IF EXISTS `EVENT_EXPIRE_ACTIVITIES` */;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8 */ ;;
/*!50003 SET character_set_results = utf8 */ ;;
/*!50003 SET collation_connection  = utf8_general_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`root`@`localhost`*/ /*!50106 EVENT `EVENT_EXPIRE_ACTIVITIES` ON SCHEDULE EVERY 1 MINUTE STARTS '2017-03-18 21:45:52' ON COMPLETION NOT PRESERVE ENABLE DO CALL `Event_ExpireActivities` () */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
/*!50106 DROP EVENT IF EXISTS `EVENT_EXPIRE_DECISIONS` */;;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8 */ ;;
/*!50003 SET character_set_results = utf8 */ ;;
/*!50003 SET collation_connection  = utf8_general_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`root`@`localhost`*/ /*!50106 EVENT `EVENT_EXPIRE_DECISIONS` ON SCHEDULE EVERY 1 MINUTE STARTS '2017-03-18 21:46:08' ON COMPLETION NOT PRESERVE ENABLE DO CALL `Event_ExpireDecisions` () */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
/*!50106 DROP EVENT IF EXISTS `EVENT_EXPIRE_WORKFLOWS` */;;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8 */ ;;
/*!50003 SET character_set_results = utf8 */ ;;
/*!50003 SET collation_connection  = utf8_general_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`root`@`localhost`*/ /*!50106 EVENT `EVENT_EXPIRE_WORKFLOWS` ON SCHEDULE EVERY 1 MINUTE STARTS '2017-03-18 21:46:26' ON COMPLETION NOT PRESERVE ENABLE DO CALL `Event_ExpireWorkflows` () */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
/*!50106 DROP EVENT IF EXISTS `EVENT_SCHEDULE_DECISIONS` */;;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8 */ ;;
/*!50003 SET character_set_results = utf8 */ ;;
/*!50003 SET collation_connection  = utf8_general_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`root`@`localhost`*/ /*!50106 EVENT `EVENT_SCHEDULE_DECISIONS` ON SCHEDULE EVERY 1 MINUTE STARTS '2017-03-18 21:46:52' ON COMPLETION NOT PRESERVE ENABLE DO CALL `Event_ScheduleDecisions` () */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
/*!50106 DROP EVENT IF EXISTS `ExpireActivities` */;;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8 */ ;;
/*!50003 SET character_set_results = utf8 */ ;;
/*!50003 SET collation_connection  = utf8_general_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`root`@`localhost`*/ /*!50106 EVENT `ExpireActivities` ON SCHEDULE AT '2017-02-19 20:56:30' ON COMPLETION NOT PRESERVE ENABLE DO CALL Event_ExpireActivities() */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
/*!50106 DROP EVENT IF EXISTS `ExpireDecisions` */;;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8 */ ;;
/*!50003 SET character_set_results = utf8 */ ;;
/*!50003 SET collation_connection  = utf8_general_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`root`@`localhost`*/ /*!50106 EVENT `ExpireDecisions` ON SCHEDULE AT '2017-02-19 20:56:45' ON COMPLETION NOT PRESERVE ENABLE DO CALL Event_ExpireDecisions() */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
/*!50106 DROP EVENT IF EXISTS `ExpireWorkflows` */;;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8 */ ;;
/*!50003 SET character_set_results = utf8 */ ;;
/*!50003 SET collation_connection  = utf8_general_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`root`@`localhost`*/ /*!50106 EVENT `ExpireWorkflows` ON SCHEDULE AT '2017-02-19 20:57:00' ON COMPLETION NOT PRESERVE ENABLE DO CALL Event_ExpireWorkflows() */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
/*!50106 DROP EVENT IF EXISTS `ScheduleActivities` */;;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8 */ ;;
/*!50003 SET character_set_results = utf8 */ ;;
/*!50003 SET collation_connection  = utf8_general_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`root`@`localhost`*/ /*!50106 EVENT `ScheduleActivities` ON SCHEDULE AT '2017-02-19 20:57:23' ON COMPLETION NOT PRESERVE ENABLE DO CALL Event_ScheduleActivities() */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
/*!50106 DROP EVENT IF EXISTS `ScheduleDecisions` */;;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8 */ ;;
/*!50003 SET character_set_results = utf8 */ ;;
/*!50003 SET collation_connection  = utf8_general_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`root`@`localhost`*/ /*!50106 EVENT `ScheduleDecisions` ON SCHEDULE AT '2017-02-19 20:57:42' ON COMPLETION NOT PRESERVE ENABLE DO CALL Event_ScheduleDecisions() */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
DELIMITER ;
/*!50106 SET TIME_ZONE= @save_time_zone */ ;

--
-- Dumping routines for database 'pinecone'
--
/*!50003 DROP PROCEDURE IF EXISTS `Event_ExpireActivities` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Event_ExpireActivities`()
BEGIN
DECLARE done INT DEFAULT FALSE;
DECLARE t_idActivityExecution varchar(45);
DECLARE t_idWorkflowExecution varchar(100);
DECLARE cur CURSOR FOR SELECT idActivityExecution,idWorkflowExecution FROM pinecone.activityexecution E, pinecone.activitytype T
		WHERE E.idExecutionStatus = 1 AND E.idActivity = T.idActivityType
		AND TIMESTAMPDIFF(SECOND, E.StartTime, utc_timestamp()) > T.TimeOut;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    
OPEN cur;

  read_loop: LOOP
    FETCH cur INTO t_idActivityExecution, t_idWorkflowExecution;
    
    IF done THEN
      LEAVE read_loop;
    END IF;
    
    DELETE FROM pinecone.activitytask
    WHERE idActivityExecution = t_idActivityExecution AND idWorkflowExecution = t_idWorkflowExecution;
    
    INSERT INTO `pinecone`.`eventexecution`
(`idWorkflowExecution`,
`Timestamp`,
`Data`,
`idEvent`,
`Metadata`)
VALUES
(t_idWorkflowExecution,
UTC_TIMESTAMP(),
NULL,
17,
NULL);

    UPDATE pinecone.activityexecution SET idExecutionStatus = 7
     WHERE idActivityExecution = t_idActivityExecution AND idWorkflowExecution = t_idWorkflowExecution; 
	
    INSERT INTO `pinecone`.`decisiontask`
(`token`,
`idWorkflowExecution`,
`Polled`)
VALUES
((SELECT LEFT(UUID(), 8)),
t_idWorkflowExecution,
0);

  END LOOP;

  CLOSE cur;
    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Event_ExpireDecisions` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Event_ExpireDecisions`()
BEGIN

DECLARE done INT DEFAULT FALSE;
DECLARE t_idWorkflowExecution varchar(100);
DECLARE cur CURSOR FOR SELECT idWorkflowExecution FROM pinecone.workflowexecution E, pinecone.workflowtype T
		WHERE E.idExecutionStatus = 1 AND E.idWorkflowType = T.idWorkflowType
		AND TIMESTAMPDIFF(SECOND, E.StartTime, utc_timestamp()) > T.DeciionTimeOut;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    
OPEN cur;

  read_loop: LOOP
    FETCH cur INTO t_idWorkflowExecution;
    
    IF done THEN
      LEAVE read_loop;
    END IF;
    
    DELETE FROM pinecone.decisiontask
    WHERE idWorkflowExecution =  t_idWorkflowExecution;
    
    INSERT INTO `pinecone`.`eventexecution`
(`idWorkflowExecution`,
`Timestamp`,
`Data`,
`idEvent`)
VALUES
(t_idWorkflowExecution,
UTC_TIMESTAMP(),
NULL,
22,
NULL);

    
        
  END LOOP;

  CLOSE cur;
    COMMIT;



END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Event_ExpireWorkflows` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Event_ExpireWorkflows`()
BEGIN

DECLARE done INT DEFAULT FALSE;
DECLARE t_idWorkflowExecution varchar(100);
DECLARE cur CURSOR FOR SELECT idWorkflowExecution FROM pinecone.workflowexecution E, pinecone.workflowtype T
		WHERE E.idExecutionStatus = 1 AND E.idWorkflowType = T.idWorkflowType
		AND TIMESTAMPDIFF(SECOND, E.StartTime, utc_timestamp()) > T.TimeOut;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    
    OPEN cur;

  read_loop: LOOP
    FETCH cur INTO t_idWorkflowExecution;
    
    IF done THEN
      LEAVE read_loop;
    END IF;
    
    DELETE FROM pinecone.activitytask
    WHERE idWorkflowExecution = t_idWorkflowExecution;
    
    DELETE FROM pinecone.activityexecution
    WHERE idWorkflowExecution = t_idWorkflowExecution;
    
    DELETE FROM pinecone.decisiontask
    WHERE idWorkflowExecution =  t_idWorkflowExecution;
    
     DELETE FROM pinecone.workflowexecution
    WHERE idWorkflowExecution =  t_idWorkflowExecution;
    
    INSERT INTO `pinecone`.`eventexecution`
(`idWorkflowExecution`,
`Timestamp`,
`Data`,
`idEvent`)
VALUES
(t_idWorkflowExecution,
UTC_TIMESTAMP(),
NULL,
6,
NULL);

    END LOOP;

  CLOSE cur;
    
    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Event_ScheduleDecisions` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Event_ScheduleDecisions`()
BEGIN
DECLARE done INT DEFAULT FALSE;
DECLARE t_idWorkflowExecution varchar(100);
DECLARE cur CURSOR FOR SELECT idWorkflowExecution FROM pinecone.workflowexecution WHERE idExecutionStatus = 1;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    OPEN cur;

  read_loop: LOOP
    FETCH cur INTO  t_idWorkflowExecution;
    
    IF done THEN
      LEAVE read_loop;
    END IF;
    
    IF NOT EXISTS(SELECT * FROM `pinecone`.`decisiontask` WHERE `idWorkflowExecution` = t_idWorkflowExecution)
    THEN
    INSERT INTO `pinecone`.`decisiontask`
(`token`,
`idWorkflowExecution`,
`Polled`)
VALUES ((SELECT LEFT(UUID(), 8)),t_idWorkflowExecution,0);
 
 
  INSERT INTO `pinecone`.`eventexecution`
(`idWorkflowExecution`,
`Timestamp`,
`Data`,
`idEvent`,`Metadata`)
VALUES
(t_idWorkflowExecution,
UTC_TIMESTAMP(),
NULL,
21,
NULL);
 END IF;
        
  END LOOP;

  CLOSE cur;
 
    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Management_DepricateActivityType` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Management_DepricateActivityType`(IN in_ActivityTypeName varchar(45),IN in_Version varchar(45))
BEGIN

DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    
   UPDATE`pinecone`.`workflowtype`
SET 
`idRegistrationStatus` = 2

WHERE `ActivityTypeName` = in_ActivityTypeName
AND `Version` = in_Version;


    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Management_DepricateDomain` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Management_DepricateDomain`(IN in_DomainName VARCHAR(45))
BEGIN

DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    
   UPDATE`pinecone`.`domain`
SET 
`idRegistrationStatus` = 2

WHERE `DomainName` = in_DomainName;


    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Management_DepricateWorkflowType` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Management_DepricateWorkflowType`(IN in_WorkflowTypeName varchar(45),IN in_Version varchar(45))
BEGIN

DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    
   UPDATE`pinecone`.`workflowtype`
SET 
`idRegistrationStatus` = 2

WHERE `WorkflowTypeName` = in_WorkflowTypeName
AND `Version` = in_Version;


    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Management_GetActivityTypes` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Management_GetActivityTypes`(IN in_DomainName varchar(45))
BEGIN
DECLARE t_idDomain INT;
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
        SELECT `idDomain` INTO t_idDomain FROM  `pinecone`.`domain` 
    WHERE `DomainName` = in_DomainName AND `idRegistrationStatus` = 1;
    
     IF(t_idDomain IS NULL)
	THEN
		SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'Invalid or depricated domain';
    END IF;
 SELECT `activitytype`.`idActivityType`,
    `activitytype`.`ActivityTypeName`,
    `activitytype`.`Version`,
    `activitytype`.`HostName`,
    `activitytype`.`idRegistrationStatus`,
    `activitytype`.`TimeOut`,
    `activitytype`.`Created`
FROM `pinecone`.`activitytype` 
WHERE `idDomain` = t_idDomain;



    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Management_GetDomains` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Management_GetDomains`()
BEGIN

DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    
 SELECT `domain`.`idDomain`,
    `domain`.`DomainName`,
    `domain`.`idRegistrationStatus`
FROM `pinecone`.`domain`;


    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Management_GetWorkflowExecutions` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Management_GetWorkflowExecutions`(IN in_DomainName varchar(45))
BEGIN
DECLARE t_idDomain INT;
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    
     SELECT `idDomain` INTO t_idDomain FROM  `pinecone`.`domain` 
    WHERE `DomainName` = in_DomainName AND `idRegistrationStatus` = 1;
    
     IF(t_idDomain IS NULL)
	THEN
		SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'Invalid or depricated domain';
    END IF;
    
SELECT E.`idWorkflowExecution`,
    E.`idExecutionStatus`,
    E.`StartTime`,
    E.`EndTime`,
    E.`idParentWorkflow`,
    T.`WorkflowTypeName`,
    T.`Version`,
    T.`HostName`,
    T.`idRegistrationStatus`,
    T.`TimeOut`,
    T.`DecisionTimeOut`
FROM `pinecone`.`workflowexecution` E,`pinecone`.`workflowtype` T
WHERE E.idWorkflowType = T.idWorkflowType AND T.idDomain = t_idDomain;


    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Management_GetWorkflowTypes` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Management_GetWorkflowTypes`(IN in_DomainName varchar(45))
BEGIN
DECLARE t_idDomain INT;
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    
    SELECT `idDomain` INTO t_idDomain FROM  `pinecone`.`domain` 
    WHERE `DomainName` = in_DomainName AND `idRegistrationStatus` = 1;
    
     IF(t_idDomain IS NULL)
	THEN
		SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'Invalid or depricated domain';
    END IF;
    
SELECT `workflowtype`.`idWorkflowType`,
    `workflowtype`.`WorkflowTypeName`,
    `workflowtype`.`Version`,
    `workflowtype`.`HostName`,
    `workflowtype`.`idRegistrationStatus`,
    `workflowtype`.`TimeOut`,
    `workflowtype`.`DecisionTimeOut`,
    `workflowtype`.`Created`
FROM `pinecone`.`workflowtype` WHERE `workflowtype`.`idDomain`= t_idDomain;



    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Management_RegisterActivityType` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Management_RegisterActivityType`(IN in_ActivityTypeName varchar(45),IN in_Version varchar(45),IN in_HostName varchar(45), IN in_TimeOut INT,
IN in_DomainName varchar(45))
BEGIN
DECLARE t_idDomain INT;
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    
    SELECT `idDomain` INTO t_idDomain FROM  `pinecone`.`domain` 
    WHERE `DomainName` = in_DomainName AND `idRegistrationStatus` = 1;
    
    IF(t_idDomain IS NULL)
	THEN
		SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'Invalid or depricated domain';
    END IF;
    
    
   INSERT INTO `pinecone`.`activitytype`
(`ActivityTypeName`,
`Version`,
`HostName`,
`idRegistrationStatus`,
`TimeOut`,
`Created`,
`idDomain`)
VALUES
(in_ActivityTypeName,
in_Version,
in_HostName,
1,
in_TimeOut,
UTC_TIMESTAMP(),
t_idDomain);

    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Management_RegisterDomain` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Management_RegisterDomain`(IN in_DomainName VARCHAR(45))
BEGIN

DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    
  INSERT INTO `pinecone`.`domain`
(`DomainName`,`idRegistrationStatus`)
VALUES
(in_DomainName,1);

    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Management_RegisterWorkflowType` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Management_RegisterWorkflowType`(IN in_WorkflowTypeName varchar(45),IN in_Version varchar(45),IN in_HostName varchar(45), IN in_TimeOut INT, IN in_DecisionTimeOut INT, IN in_DomainName varchar(45))
BEGIN
DECLARE t_idDomain INT;
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
     SELECT `idDomain` INTO t_idDomain FROM  `pinecone`.`domain` 
    WHERE `DomainName` = in_DomainName AND `idRegistrationStatus` = 1;
    
     IF(t_idDomain IS NULL)
	THEN
		SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'Invalid or depricated domain';
    END IF;
    
   INSERT INTO `pinecone`.`workflowtype`
(`WorkflowTypeName`,
`Version`,
`HostName`,
`idRegistrationStatus`,
`TimeOut`,
`DecisionTimeOut`,
`Created`,
`idDomain`)
VALUES
(in_WorkflowTypeName,
in_Version,
in_HostName,
1,
in_TimeOut,
in_DecisionTimeOut,
UTC_TIMESTAMP(),
t_idDomain);

    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Management_TerminateWorkflow` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Management_TerminateWorkflow`(IN in_idWorkflowExecution varchar(100))
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    
    UPDATE pinecone.workflowexecution
    SET EndTime = UTC_TIMESTAMP(), idExecutionStatus = 6
    WHERE idWorkflowExecution = in_idWorkflowExecution;
    
    UPDATE pinecone.activityexecution
    SET Result = in_Result, EndTime = UTC_TIMESTAMP(), idExecutionStatus = 6
    WHERE idWorkflowExecution = in_idWorkflowExecution;
    
    
    DELETE FROM `pinecone`.`decisiontask` WHERE idWorkflowExecution = in_idWorkflowExecution;
    DELETE FROM `pinecone`.`activitytask` WHERE idWorkflowExecution = in_idWorkflowExecution;
    
    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Orchestration_CompleteActivityTask` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Orchestration_CompleteActivityTask`(IN in_Token VARCHAR(8),
IN in_Result JSON)
BEGIN

DECLARE t_idWorkflowExecution varchar(100);
 DECLARE t_idActivityExecution varchar(45);
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    
IF NOT EXISTS(SELECT * FROM `pinecone`.`activitytask` WHERE token = in_Token)
THEN
		SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'Invalid or expired token.';
    END IF;

SELECT idWorkflowExecution, idActivityExecution INTO t_idWorkflowExecution,t_idActivityExecution FROM pinecone.activitytask WHERE token = in_Token;

UPDATE pinecone.activityexecution
SET Result = in_Result, EndTime = UTC_TIMESTAMP(), idExecutionStatus = 3
    WHERE idWorkflowExecution = t_idWorkflowExecution
    AND idActivityExecution = t_idActivityExecution;

INSERT INTO `pinecone`.`eventexecution`
(`idWorkflowExecution`,
`Timestamp`,
`Data`,
`idEvent`,
`MetaData`)
VALUES
(t_idWorkflowExecution,
UTC_TIMESTAMP(),
in_Result,
18,
NULL);

DELETE FROM `pinecone`.`activitytask` WHERE token = in_Token;

INSERT INTO `pinecone`.`decisiontask`
(`token`,
`idWorkflowExecution`,
`Polled`)
VALUES
((SELECT LEFT(UUID(), 8)),
t_idWorkflowExecution,
0);


    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Orchestration_CompleteDecision` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Orchestration_CompleteDecision`(IN in_Token VARCHAR(8))
BEGIN

DECLARE t_idWorkflowExecution varchar(100);
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    
IF NOT EXISTS(SELECT * FROM `pinecone`.`decisiontask` WHERE token = in_Token)
THEN
		SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'Invalid or expired token.';
    END IF;

SELECT idWorkflowExecution INTO t_idWorkflowExecution FROM pinecone.decisiontask WHERE token = in_Token;

INSERT INTO `pinecone`.`eventexecution`
(`idWorkflowExecution`,
`Timestamp`,
`Data`,
`idEvent`,
`MetaData`)
VALUES
(t_idWorkflowExecution,
UTC_TIMESTAMP(),
NULL,
23,
NULL);

DELETE FROM `pinecone`.`decisiontask` WHERE token = in_Token;


    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Orchestration_CompleteWorkflow` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Orchestration_CompleteWorkflow`(IN in_Token VARCHAR(8))
BEGIN

DECLARE t_idWorkflowExecution varchar(100);
DECLARE t_idParentWorkflow varchar(100);
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    
IF NOT EXISTS(SELECT * FROM `pinecone`.`decisiontask` WHERE token = in_Token)
THEN
		SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'Invalid or expired token.';
    END IF;

SELECT idWorkflowExecution INTO t_idWorkflowExecution FROM pinecone.decisiontask WHERE token = in_Token;

INSERT INTO `pinecone`.`eventexecution`
(`idWorkflowExecution`,
`Timestamp`,
`Data`,
`idEvent`,
`MetaData`)
VALUES
(t_idWorkflowExecution,
UTC_TIMESTAMP(),
NULL,
23,
NULL);

UPDATE pinecone.workflowexecution
SET EndTime = UTC_TIMESTAMP(), idExecutionStatus = 3
    WHERE idWorkflowExecution = t_idWorkflowExecution;

INSERT INTO `pinecone`.`eventexecution`
(`idWorkflowExecution`,
`Timestamp`,
`Data`,
`idEvent`,
`MetaData`)
VALUES
(t_idWorkflowExecution,
UTC_TIMESTAMP(),
NULL,
5,
NULL);


SELECT idParentWorkflow INTO t_idParentWorkflow FROM pinecone.workflowexecution
WHERE idWorkflowExecution = t_idWorkflowExecution;

if(t_idParentWorkflow IS NOT NULL)
THEN
	INSERT INTO `pinecone`.`eventexecution`
(`idWorkflowExecution`,
`Timestamp`,
`Data`,
`idEvent`,
`MetaData`)
VALUES
(t_idParentWorkflow,
UTC_TIMESTAMP(),
NULL,
11,
CONCAT('{"ID":"',t_idWorkflowExecution ,'"}'));


IF NOT EXISTS(SELECT 1 FROM `pinecone`.`decisiontask` WHERE `idWorkflowExecution` = t_idParentWorkflow)
THEN

	INSERT INTO `pinecone`.`decisiontask`
	(`token`,
		`idWorkflowExecution`,
		`Polled`)
	VALUES
	((SELECT LEFT(UUID(), 8)),
		t_idParentWorkflow,
		0);
END IF;


END IF;

DELETE FROM `pinecone`.`decisiontask` WHERE token = in_Token;


    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Orchestration_FailActivityTask` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Orchestration_FailActivityTask`(IN in_Token VARCHAR(8),
IN in_Result JSON)
BEGIN

DECLARE t_idWorkflowExecution varchar(100);
 DECLARE t_idActivityExecution varchar(45);
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    
IF NOT EXISTS(SELECT * FROM `pinecone`.`activitytask` WHERE token = in_Token)
THEN
		SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'Invalid or expired token.';
    END IF;

SELECT idWorkflowExecution, idActivityExecution INTO t_idWorkflowExecution,t_idActivityExecution FROM pinecone.activitytask WHERE token = in_Token;

UPDATE pinecone.activityexecution
SET Result = in_Result, EndTime = UTC_TIMESTAMP(), idExecutionStatus = 4
    WHERE idWorkflowExecution = t_idWorkflowExecution
    AND idActivityExecution = t_idActivityExecution;

INSERT INTO `pinecone`.`eventexecution`
(`idWorkflowExecution`,
`Timestamp`,
`Data`,
`idEvent`,
`MetaData`)
VALUES
(t_idWorkflowExecution,
UTC_TIMESTAMP(),
in_Result,
16,
NULL);

DELETE FROM `pinecone`.`activitytask` WHERE token = in_Token;

INSERT INTO `pinecone`.`decisiontask`
(`token`,
`idWorkflowExecution`,
`Polled`)
VALUES
((SELECT LEFT(UUID(), 8)),
t_idWorkflowExecution,
0);



    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Orchestration_FailWorkflow` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Orchestration_FailWorkflow`(IN in_Token VARCHAR(8))
BEGIN

DECLARE t_idWorkflowExecution varchar(100);
DECLARE t_idParentWorkflow varchar(100);
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    
IF NOT EXISTS(SELECT * FROM `pinecone`.`decisiontask` WHERE token = in_Token)
THEN
		SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'Invalid or expired token.';
    END IF;

SELECT idWorkflowExecution INTO t_idWorkflowExecution FROM pinecone.decisiontask WHERE token = in_Token;

INSERT INTO `pinecone`.`eventexecution`
(`idWorkflowExecution`,
`Timestamp`,
`Data`,
`idEvent`,
`MetaData`)
VALUES
(t_idWorkflowExecution,
UTC_TIMESTAMP(),
NULL,
23,
NULL);

UPDATE pinecone.workflowexecution
SET EndTime = UTC_TIMESTAMP(), idExecutionStatus = 4
    WHERE idWorkflowExecution = t_idWorkflowExecution;

INSERT INTO `pinecone`.`eventexecution`
(`idWorkflowExecution`,
`Timestamp`,
`Data`,
`idEvent`,
`MetaData`)
VALUES
(t_idWorkflowExecution,
UTC_TIMESTAMP(),
NULL,
2,
NULL);


SELECT idParentWorkflow INTO t_idParentWorkflow FROM pinecone.workflowexecution
WHERE idWorkflowExecution = t_idWorkflowExecution;

if(t_idParentWorkflow IS NOT NULL)
THEN
	INSERT INTO `pinecone`.`eventexecution`
(`idWorkflowExecution`,
`Timestamp`,
`Data`,
`idEvent`,
`MetaData`)
VALUES
(t_idParentWorkflow,
UTC_TIMESTAMP(),
NULL,
9,
CONCAT('{"ID":"',t_idWorkflowExecution ,'"}'));

INSERT INTO `pinecone`.`decisiontask`
(`token`,
`idWorkflowExecution`,
`Polled`)
VALUES
((SELECT LEFT(UUID(), 8)),
t_idParentWorkflow,
0);

IF NOT EXISTS(SELECT 1 FROM `pinecone`.`decisiontask` WHERE `idWorkflowExecution` = t_idParentWorkflow)
THEN

	INSERT INTO `pinecone`.`decisiontask`
	(`token`,
		`idWorkflowExecution`,
		`Polled`)
	VALUES
	((SELECT LEFT(UUID(), 8)),
		t_idParentWorkflow,
		0);
END IF;


END IF;

DELETE FROM `pinecone`.`decisiontask` WHERE token = in_Token;





    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Orchestration_GetCurrentActivityContext` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Orchestration_GetCurrentActivityContext`(IN in_HostName varchar(45))
BEGIN
 DECLARE this_Token varchar(8);
 DECLARE t_idWorkflowExecution varchar(100);
 DECLARE t_idActivityExecution varchar(45);
 DECLARE t_Data JSON;
 DECLARE t_ActivityTypeName varchar(45);
 DECLARE t_Version varchar(45);
 DECLARE t_idActivity INT;

DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    
    SELECT token INTO this_Token FROM pinecone.activitytask WHERE Polled = 0 LIMIT 1;
    
    IF(this_Token IS NOT NULL)
    THEN
    
    UPDATE pinecone.activitytask SET Polled = 1 WHERE token = this_Token;
    
    SELECT idWorkflowExecution, idActivityExecution INTO t_idWorkflowExecution,t_idActivityExecution FROM pinecone.activitytask WHERE token = this_Token;
    
    SELECT input, idActivity INTO t_Data,t_idActivity FROM pinecone.activityexecution
    WHERE idWorkflowExecution = t_idWorkflowExecution
    AND idActivityExecution = t_idActivityExecution;
    
    UPDATE pinecone.activityexecution SET idExecutionStatus = 1
    WHERE idWorkflowExecution = t_idWorkflowExecution
    AND idActivityExecution = t_idActivityExecution;
    
    SELECT ActivityTypeName,Version INTO t_ActivityTypeName,t_Version FROM pinecone.activitytype
    WHERE idActivityType = t_idActivity;
    
    INSERT INTO `pinecone`.`eventexecution`
(`idWorkflowExecution`,
`Timestamp`,
`Data`,
`idEvent`,
`MetaData`)
VALUES
(t_idWorkflowExecution,
UTC_TIMESTAMP(),
t_Data,
14, CONCAT('{"ID":"',t_idActivityExecution,'","Name":"',t_ActivityTypeName,'",
"Version":"',t_Version,'","HostName":"',in_HostName,'"}'));
    
    
SELECT this_Token, t_idWorkflowExecution, t_idActivityExecution,t_Data,t_ActivityTypeName,t_Version;
END IF;
    
    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Orchestration_GetCurrentWorkflowContext` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Orchestration_GetCurrentWorkflowContext`(IN in_HostName varchar(45))
BEGIN
 DECLARE this_Token varchar(8);
 DECLARE t_idWorkflowExecution varchar(100);
 
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    
    SELECT token INTO this_Token FROM pinecone.decisiontask WHERE Polled = 0 LIMIT 1;
    
    IF(this_Token IS NOT NULL)
    THEN
    UPDATE pinecone.decisiontask SET Polled = 1 WHERE token = this_Token;
    
    SELECT idWorkflowExecution INTO t_idWorkflowExecution FROM pinecone.decisiontask WHERE token = this_Token;

	INSERT INTO `pinecone`.`eventexecution`
(`idWorkflowExecution`,
`Timestamp`,
`Data`,
`idEvent`,
`MetaData`)
VALUES
(t_idWorkflowExecution,
UTC_TIMESTAMP(),
NULL,
21, NULL);
    
    SELECT W.*,T.token,E.idWorkflowExecution,E.StartTime FROM pinecone.workflowtype W, pinecone.decisiontask T, pinecone.workflowexecution E
	WHERE W.HostName = in_HostName AND T.idWorkflowExecution =  E.idWorkflowExecution 
    AND E.idWorkflowType = W.idWorkflowType AND E.idExecutionStatus = 1 AND T.Token = this_Token;
    END IF;
    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Orchestration_GetWorkflowActivities` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Orchestration_GetWorkflowActivities`(IN in_idWorkflowExecution varchar(100))
BEGIN


DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    SELECT AE.idActivityExecution,AE.input,AE.Result,AE.StartTime,AE.EndTime,AE.ScheduleTime,AE.idExecutionStatus,
    AE.idWorkflowExecution,A.ActivityTypeName,A.Version,A.HostName, A.idRegistrationStatus,A.Timeout FROM pinecone.activityexecution AE, pinecone.activitytype A
	WHERE AE.idActivity = A.idActivityType AND AE.idWorkflowExecution = in_idWorkflowExecution;
	
	COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Orchestration_GetWorkflowEvents` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Orchestration_GetWorkflowEvents`(IN in_idWorkflowExecution varchar(100))
BEGIN


DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    
	SELECT EE.*,E.EventName FROM pinecone.eventexecution EE, pinecone.event E
	WHERE EE.idEvent = E.idEvent AND EE.idWorkflowExecution = in_idWorkflowExecution
    ORDER BY EE.TimeStamp,EE.idEventExecution;
	COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Orchestration_GetWorkflowExecution` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Orchestration_GetWorkflowExecution`(IN in_idWorkflowExecution varchar(100))
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    
    
    IF EXISTS
    (SELECT * FROM pinecone.workflowexecution WHERE idWorkflowExecution = in_idWorkflowExecution
	AND idExecutionStatus NOT IN (1,2))
    THEN

    SELECT Result FROM pinecone.activityexecution WHERE idWorkflowExecution = in_idWorkflowExecution
    ORDER BY EndTime DESC LIMIT 1;
    
     
     
     ELSE
     SELECT 'OPEN';
     END IF;

    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Orchestration_Initiate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Orchestration_Initiate`(IN in_WorkflowTypeName varchar(45),IN in_DomainName varchar(45),IN in_Version varchar(45), IN in_Data JSON,
IN in_idWorkflowExecution VARCHAR(100))
BEGIN

DECLARE t_idWorkflowType INT;
DECLARE t_idDomain INT;

DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    
    SELECT `idDomain` INTO t_idDomain FROM  `pinecone`.`domain` 
    WHERE `DomainName` = in_DomainName AND `idRegistrationStatus` = 1;
    
    IF(t_idDomain IS NULL)
	THEN
		SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'Invalid or depricated domain';
    END IF;
    
    SELECT `idWorkflowType` INTO t_idWorkflowType FROM  `pinecone`.`workflowtype`
    WHERE `WorkflowTypeName` = in_WorkflowTypeName AND `idRegistrationStatus` = 1;
    
    IF(t_idWorkflowType IS NULL)
	THEN
		SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'Invalid or depricated workflow type';
    END IF;
    
  INSERT INTO `pinecone`.`workflowexecution`
(`idWorkflowExecution`,
`idWorkflowType`,
`idExecutionStatus`,
`StartTime`,
`EndTime`)
VALUES
(in_idWorkflowExecution,
t_idWorkflowType,
1,
UTC_TIMESTAMP(),
NULL);

INSERT INTO `pinecone`.`eventexecution`
(`idWorkflowExecution`,
`Timestamp`,
`Data`,
`idEvent`)
VALUES
(in_idWorkflowExecution,
UTC_TIMESTAMP(),
in_Data,
1);

INSERT INTO `pinecone`.`eventexecution`
(`idWorkflowExecution`,
`Timestamp`,
`Data`,
`idEvent`)
VALUES
(in_idWorkflowExecution,
UTC_TIMESTAMP(),
in_Data,
20);

INSERT INTO `pinecone`.`decisiontask`
(`token`,
`idWorkflowExecution`,
`Polled`)
VALUES
((SELECT LEFT(UUID(), 8)),
in_idWorkflowExecution,
0);

    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Orchestration_InitiateActivity` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Orchestration_InitiateActivity`(IN in_ActivityTypeName varchar(45),IN in_Version varchar(45), IN in_Data JSON,
IN in_Token VARCHAR(8), IN in_idActivityExecution VARCHAR(45), IN in_HostName VARCHAR(45))
BEGIN

DECLARE t_idActivityType INT;
DECLARE t_idWorkflowExecution varchar(100);

DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    
	SELECT idWorkflowExecution INTO t_idWorkflowExecution FROM pinecone.decisiontask WHERE token = in_Token;

    
    
    SELECT `idActivityType` INTO t_idActivityType FROM  `pinecone`.`activitytype`
    WHERE `ActivityTypeName` = in_ActivityTypeName AND `idRegistrationStatus` = 1;
    
    IF(t_idActivityType IS NULL)
	THEN
		SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'Invalid or depricated activity type';
    END IF;
    
  
INSERT INTO `pinecone`.`eventexecution`
(`idWorkflowExecution`,
`Timestamp`,
`Data`,
`idEvent`,
`Metadata`)
VALUES
(t_idWorkflowExecution,
UTC_TIMESTAMP(),
in_Data,
13,CONCAT('{"ID":"',in_idActivityExecution ,'","Name":"',in_ActivityTypeName,'","Version":"',in_Version,'","HostName":"',in_HostName,'"}'));

INSERT INTO `pinecone`.`activityexecution`
(`idActivityExecution`,
`idActivity`,
`Input`,
`Result`,
`StartTime`,
`EndTime`,
`ScheduleTime`,
`idExecutionStatus`,
`idWorkflowExecution`)
VALUES
(in_idActivityExecution,
t_idActivityType,
in_Data,
NULL,
UTC_TIMESTAMP(),
NULL,
UTC_TIMESTAMP(),
2,
t_idWorkflowExecution);

INSERT INTO `pinecone`.`activitytask`
(`token`,
`idWorkflowExecution`,`Polled`,`idActivityExecution`)
VALUES
((SELECT LEFT(UUID(), 8)),
t_idWorkflowExecution,
0,in_idActivityExecution);

    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Orchestration_InitiateChildWorkflow` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Orchestration_InitiateChildWorkflow`(IN in_WorkflowTypeName varchar(45),IN in_Version varchar(45), IN in_Data JSON,
IN in_idWorkflowExecution VARCHAR(100),IN in_Token VARCHAR(8), IN in_HostName VARCHAR(45))
BEGIN

DECLARE t_idWorkflowType INT;
DECLARE t_DomainName VARCHAR(45);
DECLARE t_idWorkflowExecution varchar(100);
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    SELECT idWorkflowExecution INTO t_idWorkflowExecution FROM pinecone.decisiontask WHERE token = in_Token;

    
    
       
    SELECT `idWorkflowType` INTO t_idWorkflowType FROM  `pinecone`.`workflowtype`
    WHERE `WorkflowTypeName` = in_WorkflowTypeName AND `idRegistrationStatus` = 1;
    
    IF(t_idWorkflowType IS NULL)
	THEN
		SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'Invalid or depricated workflow type';
    END IF;
    
    SELECT DomainName INTO t_DomainName FROM pinecone.domain D, pinecone.workflowtype W
WHERE D.idDomain = W.idDomain AND W.idWorkflowType = t_idWorkflowType;
    
CALL `pinecone`.`Orchestration_Initiate`(in_WorkflowTypeName, t_DomainName, in_Version, in_Data, in_idWorkflowExecution);


UPDATE `pinecone`.`workflowexecution`
SET
`idParentWorkflow` = t_idWorkflowExecution
WHERE `idWorkflowExecution` = in_idWorkflowExecution;


INSERT INTO `pinecone`.`eventexecution`
(`idWorkflowExecution`,
`Timestamp`,
`Data`,
`idEvent`,
`Metadata`)
VALUES
(t_idWorkflowExecution,
UTC_TIMESTAMP(),
in_Data,
7,CONCAT('{"ID":"', in_idWorkflowExecution ,'","Name":"',in_WorkflowTypeName,'",
"Version":"',in_Version,'","HostName":"',in_HostName,'"}'));

INSERT INTO `pinecone`.`eventexecution`
(`idWorkflowExecution`,
`Timestamp`,
`Data`,
`idEvent`,
`Metadata`)
VALUES
(t_idWorkflowExecution,
UTC_TIMESTAMP(),
in_Data,
8,
NULL);


    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Orchestration_RecordMarker` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Orchestration_RecordMarker`(IN in_Data JSON,
IN in_Token VARCHAR(8))
BEGIN

DECLARE t_idWorkflowExecution varchar(100);
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    
SELECT idWorkflowExecution INTO t_idWorkflowExecution FROM pinecone.decisiontask WHERE token = in_Token;


INSERT INTO `pinecone`.`eventexecution`
(`idWorkflowExecution`,
`Timestamp`,
`Data`,
`idEvent`,
`MetaData`)
VALUES
(t_idWorkflowExecution,
UTC_TIMESTAMP(),
NULL,
19,
in_Data);


    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Orchestration_TerminateWorkflow` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Orchestration_TerminateWorkflow`(IN in_Token VARCHAR(8))
BEGIN

DECLARE t_idWorkflowExecution varchar(100);
DECLARE t_idParentWorkflow varchar(100);
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
    
IF NOT EXISTS(SELECT * FROM `pinecone`.`decisiontask` WHERE token = in_Token)
THEN
		SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'Invalid or expired token.';
    END IF;

SELECT idWorkflowExecution INTO t_idWorkflowExecution FROM pinecone.decisiontask WHERE token = in_Token;

UPDATE pinecone.workflowexecution
SET EndTime = UTC_TIMESTAMP(), idExecutionStatus = 6
    WHERE idWorkflowExecution = t_idWorkflowExecution;

INSERT INTO `pinecone`.`eventexecution`
(`idWorkflowExecution`,
`Timestamp`,
`Data`,
`idEvent`,
`MetaData`)
VALUES
(t_idWorkflowExecution,
UTC_TIMESTAMP(),
t_Data,
4,
NULL);


SELECT idParentWorkflow INTO t_idParentWorkflow FROM pinecone.workflowexecution
WHERE idWorkflowExecution = t_idWorkflowExecution;

if(t_idParentWorkflow IS NOT NULL)
THEN
	INSERT INTO `pinecone`.`eventexecution`
(`idWorkflowExecution`,
`Timestamp`,
`Data`,
`idEvent`,
`MetaData`)
VALUES
(t_idParentWorkflow,
UTC_TIMESTAMP(),
t_Data,
10,
NULL);

IF NOT EXISTS(SELECT 1 FROM `pinecone`.`decisiontask` WHERE `idWorkflowExecution` = t_idParentWorkflow)
THEN

	INSERT INTO `pinecone`.`decisiontask`
	(`token`,
		`idWorkflowExecution`,
		`Polled`)
	VALUES
	((SELECT LEFT(UUID(), 8)),
		t_idParentWorkflow,
		0);
END IF;

END IF;

DELETE FROM `pinecone`.`decisiontask` WHERE token = in_Token;




    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RegisterDomain` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `RegisterDomain`(IN in_DomainName varchar(45))
BEGIN

DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;
INSERT INTO `pinecone`.`domain`
(`DomainName`,
`idRegistrationStatus`)
VALUES
(in_DomainName,1);

COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-03-18 22:04:25
